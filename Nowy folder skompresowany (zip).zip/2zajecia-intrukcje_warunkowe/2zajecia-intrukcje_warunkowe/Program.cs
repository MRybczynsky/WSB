﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2zajecia_intrukcje_warunkowe
{
    class Program
    {
        static void Main(string[] args)
        {
            int y= 5;
            if (y>3)
            {
                Console.WriteLine("prawda");
            }
            else if (y == 5)
            {
                Console.WriteLine("y rowny 5");
            }
            else
            {
                Console.WriteLine("falsz");
            }
            Console.Write("Podaj dlugosc podstawy: ");
            string x = Console.ReadLine();
            Console.Write("Podaj wysokosc: ");
            string h = Console.ReadLine();
            double x1,h1;
            if(double.TryParse(x,out x1)&&(double.TryParse(h, out h1)))
            {
                    double pole = 0.5 * (x1 * h1);
                    Console.WriteLine("Pole wynosi " + pole + " cm kawdratowych");
                    //Console.WriteLine("Pole wynosi {0}", pole);
            }
            else
            {
                Console.WriteLine("Error!!!");
            }
            Console.ReadKey();
        }
    }
}
