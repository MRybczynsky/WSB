﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zajecia2___interacja_for
{
    class Program
    {
        static void Main(string[] args)
        {
            /*int n=15;
            for (int i=1; i<=n; i++) // (inicjalizacja; warunek; np.inkrementacja)
            {
                Console.Write("{0} ", i); // interpolacja - sposób szybszy od konkatenacji tj. (i + " ")
            }
            Console.ReadKey();

            //wyswietl liczby parzyste z przedzialu od 5 do 20 w pozadku malejacym
            for (int i = 20; i >= 5; i--) 
            {
                if (i % 2 == 0)
                {
                    Console.Write("{0} ", i);
                }
            }*/

            /* wyswietl na ekranie
                *
                **
                ***
                ****
                wysokosc choinki uzytkownik wprowadza z klawiatury
            */
            Console.Write("Podaj wysokosc choinki: ");
            string n;
            int n1;
            n = Console.ReadLine();

            if (int.TryParse(n, out n1))
            {
                for (int i = 1; i <= n1; i++)
                {
                    for (int j = 0; j < i; j++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();
                }
            }
            Console.ReadKey();
        }
    }
}
