﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zajecia2___switch_case
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;
            Console.WriteLine("1 - pole kwadratu\n2- pole kola");
            Console.Write("Wybierz: ");
            a = Console.ReadLine();
            switch (a)
            {
                case "1":
                    {
                        Console.Clear();
                        Console.WriteLine("Wybrales pole kwadratu");
                        Console.Write("Podaj dlugosc podstawy: ");
                        string x = Console.ReadLine();
                        double x1;
                        if (double.TryParse(x, out x1))
                        {
                            double pole = x1*x1;
                            Console.WriteLine("Pole wynosi {0:##.##}", pole, "jednostek kwadratowych");
                        }
                        else
                        {
                            Console.WriteLine("Error!!!");
                        }
                        break;
                    }
                case "2":
                    {
                        Console.Clear();
                        Console.WriteLine("Wybrales pole kola");
                        Console.Write("Podaj dlugosc promienia: ");
                        string r = Console.ReadLine();
                        double r1;
                        if (double.TryParse(r, out r1)) // sprawdzanie czy nie tekst
                        {
                            double pole2 = Math.PI*r1*r1; // instrukcja Math - przywolanie instrukcji matematycznej np. pi lub pierwiastek z wartosci 
                            Console.WriteLine("Pole wynosi {0:##.##}", pole2, "jednostek kwadratowych"); // {0:##.##} ustawianie formatu 
                        }
                        else
                        {
                            Console.WriteLine("Error!!!"); 
                        }
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Blad wyboru!");
                        break;
                    }
            }
            Console.ReadKey();
        }
    }
}
